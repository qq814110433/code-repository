# mmall20180107
采用SSM框架的电商网站，数据库采用的是MySql。包含用户管理，订单，品类，产品，购物车，地址，在线支付七个模块。项目的演进会逐步融合tomcat集群，nginx负载均衡，redis缓存分布式，redis分布式锁，单点登录，Spring Session，Spring Schedule定时关单，Redisson等
