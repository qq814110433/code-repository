龙果开源-Mybatis代码自动生成工具

### 更新日志
2017-10-21 增加bjui、jui工具类和集合属性复制工具类

2017-10-15 新增Dao层插件（可以当做Service层）-DaoPlugin.java

2017-02-24 对配置文件xml增加生成表的说明

2017-02-13 修改源码DefaultCommentGenerator类，增加数据库的字段注释。

### 项目介绍
1. 基于mybatis-generator，增加了多个插件。


### 帮助文档
1. 修改src/test/resources/下的配置文件
2. 运行src/test/test/下的main方法即可

### 技术交流
* QQ2群: 601146630
* QQ1群: 213097382 (满)

