# maven-itzixi-ssm-wxpay
maven 整合的微信扫码支付

2017-09-04 更新：
录了视频，并且整合到了订单流程
可以选择支付宝或者微信扫码进行支付
http://www.itzixi.com/course/detail.shtml?courseId=1709029W0AFN7X1P
